package dev.zorowarrior.bridge;

import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.client.resources.model.ModelResourceLocation;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraftforge.client.model.ModelLoader;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.registry.GameRegistry;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

/**
 * ZOROWARRIOR HORIZON BRIDGE — Minecraft 1.8.9, Forge.
 *
 * <p>A genuinely different implementation, not a copy. 1.8.9 predates the
 * registry system: blocks and items are handed to {@code GameRegistry.registerBlock}
 * / {@code registerItem} with a name, there is no {@code Block.Settings}, and
 * models are registered at runtime through {@code ModelLoader}. Nothing here
 * compiles on 1.21.x and the
 * 1.21.x source does not compile here — which is why the jars are separate.
 *
 * <p>Details that differ from modern versions and are easy to get wrong:
 * <ul>
 *   <li>{@code ModelResourceLocation} is in {@code net.minecraft.client.resources.model}
 *       (it moved to {@code ...client.renderer.block.model} in 1.9).</li>
 *   <li>{@code Block.setHarvestLevel} returns {@code void}, so it cannot be
 *       chained onto the block builder.</li>
 *   <li>Registration is {@code GameRegistry.registerBlock} / {@code registerItem}
 *       with an explicit name — {@code register(IForgeRegistryEntry)} did not
 *       exist until 1.9.</li>
 *   <li>Recipes are code, not JSON — data packs did not exist in 1.8.9.</li>
 *   <li>Textures live in {@code textures/blocks} and {@code textures/items}.</li>
 * </ul>
 */
@Mod(modid = BridgeMod.MODID, version = BridgeMod.VERSION,
     name = "ZOROWARRIOR HORIZON BRIDGE",
     acceptedMinecraftVersions = "[1.8.9]")
public class BridgeMod {

    public static final String MODID = "zoro_bridge";
    public static final String VERSION = "1.0.0";

    public static Block bridgeBeacon;
    public static Item bridgeChip;

    @Mod.EventHandler
    public void preInit(FMLPreInitializationEvent event) {
        bridgeBeacon = new Block(Material.field_151576_e);
        bridgeBeacon.func_149711_c(3.5F);
        bridgeBeacon.func_149752_b(6.0F);
        bridgeBeacon.func_149715_a(12.0F / 15.0F);
        bridgeBeacon.func_149672_a(Block.field_149769_e);
        bridgeBeacon.func_149663_c("bridge_beacon");
        bridgeBeacon.func_149647_a(CreativeTabs.field_78030_b);
        // Returns void in 1.8.9 — cannot be part of a fluent chain.
        bridgeBeacon.setHarvestLevel("pickaxe", 2);
        // 1.8.9 Forge: GameRegistry.registerBlock / registerItem with an explicit
        // name. The modern register(IForgeRegistryEntry) arrived in 1.9.
        GameRegistry.registerBlock(bridgeBeacon, "bridge_beacon");

        bridgeChip = new Item();
        bridgeChip.func_77655_b("bridge_chip");
        bridgeChip.func_77637_a(CreativeTabs.field_78035_l);
        bridgeChip.func_77625_d(64);
        GameRegistry.registerItem(bridgeChip, "bridge_chip");

        ItemBlock beaconItem = new ItemBlock(bridgeBeacon);
        GameRegistry.registerItem(beaconItem, "bridge_beacon");

        // 1.8.9 recipes: position strings plus a key, resolved at load time.
        GameRegistry.addRecipe(new ItemStack(bridgeChip),
                " G ",
                "GDG",
                " G ",
                'G', new ItemStack(net.minecraft.init.Items.field_151043_k),
                'D', new ItemStack(net.minecraft.init.Items.field_151045_i));
        GameRegistry.addRecipe(new ItemStack(bridgeBeacon),
                "SSS",
                "SCS",
                "SSS",
                'S', new ItemStack(net.minecraft.init.Blocks.field_150348_b),
                'C', new ItemStack(bridgeChip));
    }

    /**
     * 1.8.9 resolves models from {@code blockstates/} and {@code models/} via the
     * resource pack, but the item-to-model binding for an ItemBlock still has to
     * be declared in code.
     */
    @SideOnly(Side.CLIENT)
    @Mod.EventHandler
    public void init(FMLInitializationEvent event) {
        ModelLoader.setCustomModelResourceLocation(
                Item.func_150898_a(bridgeBeacon), 0,
                new ModelResourceLocation(MODID + ":bridge_beacon", "inventory"));
        ModelLoader.setCustomModelResourceLocation(
                bridgeChip, 0,
                new ModelResourceLocation(MODID + ":bridge_chip", "inventory"));
    }
}
